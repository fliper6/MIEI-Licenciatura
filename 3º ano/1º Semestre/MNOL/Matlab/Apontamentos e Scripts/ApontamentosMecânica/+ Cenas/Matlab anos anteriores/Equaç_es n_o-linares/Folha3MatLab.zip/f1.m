function y=f1(x)
% ------------------------------------------------------------------
% Calcula os valores para a fun��o FP 3- Exercicio 4
% f(x)= exp(-x)-sin(7.*x)
%-----------------------------------

y=exp(-x)-sin(7.*x);