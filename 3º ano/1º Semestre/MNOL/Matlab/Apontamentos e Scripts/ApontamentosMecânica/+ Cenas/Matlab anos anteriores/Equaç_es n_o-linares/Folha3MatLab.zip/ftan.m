function y=ftan(x)
y = 1 - x.*tan(x);