function y=fex(x)
  y= 1- x.*tan(x);
  