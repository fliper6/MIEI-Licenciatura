var searchData=
[
  ['read_20attributes_20and_20text_20information_2e',['Read attributes and text information.',['../_example_4.html',1,'']]],
  ['rootelement',['RootElement',['../classtinyxml2_1_1_x_m_l_document.html#ad2b70320d3c2a071c2f36928edff3e1c',1,'tinyxml2::XMLDocument']]]
];
